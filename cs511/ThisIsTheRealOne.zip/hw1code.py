#Michael John
#Homework 1 help
#This code was a working solution. Along the way I was able to get results that helped me produce a result. This code doesn't necessarily work but it functioned at times, and enough to help me create a solution.

cipher = ["2d0a0612061b0944000d161f0c1746430c0f0952181b004c1311080b4e07494852",
          "200a054626550d051a48170e041d011a001b470204061309020005164e15484f44",
          "3818101500180b441b06004b11104c064f1e0616411d064c161b1b04071d460101",
          "200e0c4618104e071506450604124443091b09520e125522081f061c4e1d4e5601",
          "304f1d091f104e0a1b48161f101d440d1b4e04130f5407090010491b061a520101",
          "2d0714124f020111180c450900595016061a02520419170d1306081c1d1a4f4601",
          "351a160d061917443b3c354b0c0a01130a1c01170200191541070c0c1b01440101",
          "3d0611081b55200d1f07164b161858431b0602000454020d1254084f0d12554249",
          "340e0c040a550c1100482c4b0110450d1b4e1713185414181511071b071c4f0101",
          "2e0a5515071a1b081048170e04154d1a4f020e0115111b4c151b492107184e5201",
          "370e1d4618104e05060d450f0a104f044f080e1c04540205151c061a1a5349484c"]
output = [[0]*33]*11
real = [0]*11

def initalize():
    for i in range(11):
        #real[i] = 0
        for j in range(33):
            output[i][j] = 0

def str_to_list(string):
    a = [0]*33
    count = 0
    for i in range(33):
        x = string[0] + string[1]
        string = string[2:]
        a[count] = x
        count += 1
        #print(i)
    return a

def str_hex(st):
    st = "0x"+st
    hex_int = int(st, 16)
    return hex_int

def ryan(lst):
    return list(map(str_hex, lst))

def check_case(j):
    return (j>64 and j<91) or (j>96 and j<123)

def change_case(i):
    if(i < 91):
        i += 32
    if(i > 96):
        i -= 32
    return i

def func(lst, col):
    space = 0
    for i in range(2,11):
        x = lst[i-2]^lst[i-1]
        y = lst[i-1]^lst[i]
        if(check_case(x) and check_case(y)):
            space = lst[i-1]
            row = i-1
            #print "this is a space"
            #print row
            for j in range(11):
                if(lst[j] == space):
                    output[row][col] = 0x20
                    continue;
                output[row][col] = change_case(lst[j]^lst[row])
            break;

def make_char():
    #string = ""
    for i in range(11):
        string = ""
        for j in range(33):
            #print(output[i][j])
            #print(type(output[i][j]))
            output[i][j] = chr(output[i][j])
            #print(output[i][j])
            string = string+output[i][j]
        real[i] = string
        #string = ""

def tiny(col):
    a = [0]*11
    for i in range(11):
        a[i] = cipher[i][col]
    #print(a)
    return a

def Simple(liist):
    for i in range(2,11):
        x = liist[i-2]^liist[i-1]
        y = liist[i-1]^liist[i]
        if(check_case(x) and check_case(y)):
            space = liist[i-1]
            helper(liist,space)
def helper(liist,space):
    for j in liist:
        #print(j)
        print(chr( j ^ 68))
'''space = liist[i-1]
            for j in liist:
              #  print(j)
                print(chr(j ^ space))
        else:
            continue'''

def mega(intt):
    count = 0
    initalize()
    for i in range(11):
        cipher[i] = ryan(str_to_list(cipher[i]))
    for i in range(33):
        print(tiny(i),i)
    Simple(tiny(intt))
    #helper(tiny(6),6,4)
    #print(output)
       
        


'''for j in range(32):
            
            func(i,count)
        count+=1
    make_char()
'''